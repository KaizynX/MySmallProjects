from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


import pandas as pd


# Here is only a template for your reference, you only need to ensure the predict function can 
# receive the test dataset and return the prediction results.



class MachineLearningModel:
    def __init__(self):
        # 创建多个模型
        # clf1 = XGBClassifier()
        clf2 = RandomForestClassifier(n_estimators=50, random_state=1)
        clf3 = SVC(kernel="rbf", C=0.5, gamma="auto", probability=True)
        clf4 = KNeighborsClassifier()

        # 创建 VotingClassifier
        self.model = VotingClassifier(estimators=[
            # ("xgb", clf1), 
            ("rf", clf2), 
            ("svc", clf3), 
            ("knn", clf4)
        ], voting="soft")

        df_train = pd.read_csv("./train.csv")
        self.train(df_train)

    def train(self, data: pd.DataFrame):
        self.model = self.model.fit(data.drop("Label", axis=1), data["Label"])

    def predict(self, data: pd.DataFrame):
        return self.model.predict(data)